from django.urls import path
from .views import login_user, register_user, log_out, user_account_main_page

urlpatterns = [
    path('login', login_user),
    path('register', register_user),
    path('logout', log_out),
    path('user', user_account_main_page)
]