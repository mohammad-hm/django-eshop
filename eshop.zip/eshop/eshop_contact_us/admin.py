from django.contrib import admin
from .models import ContactUs

# Register your models here.


class ProductAdmin(admin.ModelAdmin):
    list_display = ['subject', 'is_read']
    list_filter = ['is_read']

    class Meta:
        model = ContactUs


admin.site.register(ContactUs, ProductAdmin)
