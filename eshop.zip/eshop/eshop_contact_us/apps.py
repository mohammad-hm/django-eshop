from django.apps import AppConfig


class EshopContactUsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eshop_contact_us'
    verbose_name = 'ماژول تماس ها'
