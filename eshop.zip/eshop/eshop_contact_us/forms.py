from django import forms
from django.core import validators


class ContactForm(forms.Form):
    fullname = forms.CharField(
        widget=forms.TextInput(
            attrs={'placeholder': 'لطفا نام و نام خانوادگی خود را وارد نمایید', 'class': 'form-control'}),
        label='نام و نام خانوادگی',
        validators=[
            validators.MinLengthValidator(limit_value=5, message='نام و نام خانوادگی باید بیشتر از 5 حرف باشد')]
    )

    email = forms.EmailField(
        widget=forms.EmailInput(
            attrs={'placeholder': 'لطفا ایمیل خود را وارد نمایید', 'class': 'form-control'}),
        label='ایمیل'
    )

    subject = forms.CharField(
        widget=forms.TextInput(
            attrs={'placeholder': 'لطفا عنوان خود را وارد نمایید', 'class': 'form-control'}),
        label='عنوان'
    )

    text = forms.CharField(
        widget=forms.Textarea(
            attrs={'placeholder': 'لطفا متن پیغام خود را وارد نمایید', 'class': 'form-control', 'rows': '8', 'id': 'message'}),
        label='متن پیغام'
    )