from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

# Create your views here.
from eshop_order.forms import UserNewOrderForm
from eshop_order.models import Order, OrderDetail
from eshop_products.models import Product

#  zarinpal
from django.http import HttpResponse, Http404
from django.shortcuts import redirect
from zeep import Client
import requests
import json


@login_required(login_url='/login')
def add_user_order(request):
    new_order_form = UserNewOrderForm(request.POST or None)  # create form for first time - in deatil teamplate we send th form to html

    if new_order_form.is_valid():
        order = Order.objects.filter(owner_id=request.user.id, is_paid=False).first()  # check if User has a open order
        if order is None:  # check if User has no order at all
            order = Order.objects.create(owner_id=request.user.id, is_paid=False)  # create order for first time

        product_id = new_order_form.cleaned_data.get('product_id')  # get prodcut_id from form in html
        count = new_order_form.cleaned_data.get('count')  # get count from form in html
        if count < 0:
            count = 1
        product = Product.objects.get_by_id(product_id=product_id)
        order.orderdetail_set.create(product=product, price=product.price, count=count)  # create order detail
        # todo: redirect user to user panel
        # return redirect('/user/orders')
        return redirect(f'/products/{product.id}/{product.title.replace(" ", "-")}')

    return redirect('/')


@login_required(login_url='/login')
def user_open_order(request):
    context = {
        'order': None,
        'details': None
    }
    open_order: Order = Order.objects.filter(owner_id=request.user.id, is_paid=False).first()  # get order for this user
    if open_order is not None:
        context['order'] = open_order
        context['details'] = open_order.orderdetail_set.all()
    return render(request, 'order/user_order_open.html', context)


@login_required(login_url='/login')
def remove_open_order(request, *args, **kwargs):
    order_details_id = kwargs.get('order_detail_id')
    if order_details_id is not None:
        remove_order_item = OrderDetail.objects.filter(id=order_details_id, order__owner_id=request.user.id)
        if remove_order_item is not None:
            remove_order_item.delete()
            return redirect('/order-open')
    raise Http404()


MERCHANT = 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX'
ZP_API_REQUEST = "https://api.zarinpal.com/pg/v4/payment/request.json"
ZP_API_VERIFY = "https://api.zarinpal.com/pg/v4/payment/verify.json"
ZP_API_STARTPAY = "https://www.zarinpal.com/pg/StartPay/{authority}"
amount = 11000  # Rial / Required
description = "توضیحات مربوط به تراکنش را در این قسمت وارد کنید"  # Required
email = 'email@example.com'  # Optional
mobile = '09123456789'  # Optional
# Important: need to edit for realy server.
CallbackURL = 'http://localhost:8000/verify/'


def send_request(request):
    total_price = 0
    open_order: Order = Order.objects.filter(is_paid=False, owner_id=request.user.id).first()
    if open_order is not None:
        total_price = open_order.get_total_price()
        req_data = {
            "merchant_id": MERCHANT,
            "amount": total_price,
            "callback_url": CallbackURL,
            "description": description,
            "metadata": {"mobile": mobile, "email": email}
        }
        req_header = {"accept": "application/json",
                      "content-type": "application/json'"}
        req = requests.post(url=ZP_API_REQUEST, data=json.dumps(
            req_data), headers=req_header)
        authority = req.json()['data']['authority']
        if len(req.json()['errors']) == 0:
            return redirect(ZP_API_STARTPAY.format(authority=authority))
        else:
            e_code = req.json()['errors']['code']
            e_message = req.json()['errors']['message']
            return HttpResponse(f"Error code: {e_code}, Error Message: {e_message}")
    raise Http404()


def verify(request):
    t_status = request.GET.get('Status')
    t_authority = request.GET['Authority']
    if request.GET.get('Status') == 'OK':
        req_header = {"accept": "application/json",
                      "content-type": "application/json'"}
        req_data = {
            "merchant_id": MERCHANT,
            "amount": amount,
            "authority": t_authority
        }
        req = requests.post(url=ZP_API_VERIFY, data=json.dumps(req_data), headers=req_header)
        if len(req.json()['errors']) == 0:
            t_status = req.json()['data']['code']
            if t_status == 100:
                return HttpResponse('Transaction success.\nRefID: ' + str(
                    req.json()['data']['ref_id']
                ))
            elif t_status == 101:
                return HttpResponse('Transaction submitted : ' + str(
                    req.json()['data']['message']
                ))
            else:
                return HttpResponse('Transaction failed.\nStatus: ' + str(
                    req.json()['data']['message']
                ))
        else:
            e_code = req.json()['errors']['code']
            e_message = req.json()['errors']['message']
            return HttpResponse(f"Error code: {e_code}, Error Message: {e_message}")
    else:
        return HttpResponse('Transaction failed or canceled by user')







# MERCHANT = 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX'  # this code is taken form zarinpal site
# amount = 1000  # Toman / Required  # the price that sending to zarinpal
# description = "توضیحات مربوط به تراکنش را در این قسمت وارد کنید"  # Required
# email = 'email@example.com'  # Optional
# mobile = '09123456789'  # Optional
# client = Client('https://www.zarinpal.com/pg/services/WebGate/wsdl')  # send or redirect User info to the zarinpal
# CallbackURL = 'http://localhost:8000/verify/'  # Important: need to edit for realy server.  # this is the adrress that user go  ther after paying


# def send_request(request, *args, **kwargs):  # sending User to zarinpal site
#     order_id = kwargs.get('order-id')
#     total_price = 0
#     open_order: Order = Order.objects.filter(owner_id=request.user.id, is_paid=False).first()  # get order for this user
#     if open_order is not None:
#         total_price = open_order.get_total_price()
#
#     result = client.service.PaymentRequest(MERCHANT, amount, description, email, mobile, CallbackURL)  # check if the User info is ok
#     if result.Status == 100:
#         return redirect('https://www.zarinpal.com/pg/StartPay/' + str(result.Authority))
#     else:
#         return HttpResponse('Error code: ' + str(result.Status))

#
# def verify(request):  # when User back to the our site , this methode start
#     if request.GET.get('Status') == 'OK':
#         result = client.service.PaymentVerification(MERCHANT, request.GET['Authority'], amount)  # check if the payment operation is ok or not
#         if result.Status == 100:
#             return HttpResponse('Transaction success.\nRefID: ' + str(result.RefID))
#         elif result.Status == 101:
#             return HttpResponse('Transaction submitted : ' + str(result.Status))
#         else:
#             return HttpResponse('Transaction failed.\nStatus: ' + str(result.Status))
#     else:
#         return HttpResponse('Transaction failed or canceled by user')
