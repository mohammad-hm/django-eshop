from django.apps import AppConfig


class EshopProductsCategoryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eshop_products_category'
    verbose_name = 'ماژول دسته بندی ها'
