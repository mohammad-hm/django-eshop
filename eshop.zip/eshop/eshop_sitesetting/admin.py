from django.contrib import admin
from .models import SiteSetting

# Register your models here.


class ProductAdmin(admin.ModelAdmin):
    list_display = ['title']

    class Meta:
        model = SiteSetting


admin.site.register(SiteSetting, ProductAdmin)
