from django.contrib import admin
from .models import Slider

# Register your models here.


class ProductAdmin(admin.ModelAdmin):
    list_display = ['title', 'link']

    class Meta:
        model = Slider


admin.site.register(Slider, ProductAdmin)