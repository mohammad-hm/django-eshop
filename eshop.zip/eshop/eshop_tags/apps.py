from django.apps import AppConfig


class EshopTagsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eshop_tags'
    verbose_name = 'ماژول برچسب ها'
